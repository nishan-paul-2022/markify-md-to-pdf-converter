# Orphaned Image Failure
I have an image in images/ but I don't reference it.

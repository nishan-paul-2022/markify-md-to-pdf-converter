# Baggage File Failure
This folder has a .txt file.

![Ref](img.jpg)

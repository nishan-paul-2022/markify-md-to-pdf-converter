This is a forbidden baggage file.

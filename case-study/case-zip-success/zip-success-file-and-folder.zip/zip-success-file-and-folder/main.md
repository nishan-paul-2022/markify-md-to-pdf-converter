# Success Baseline
This is a valid project structure.
Here is a photo: ![Photo](images/img-06.jpg)

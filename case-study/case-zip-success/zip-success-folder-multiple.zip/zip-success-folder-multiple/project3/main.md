# Wrapped Project
This is a project inside a single wrapper folder.
![Ref](images/img-01.jpg)
